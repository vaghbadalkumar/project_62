# PRO-C62-APP-PUBLISHING-AND-LOCAL-ENVIRONMENT-SETUP
In This Project, We Shall Practice The Same Concept And Generate An Apk (For Android) And Ipa (For Ios) For The App You Already Made Called “Student Attendance App”.
