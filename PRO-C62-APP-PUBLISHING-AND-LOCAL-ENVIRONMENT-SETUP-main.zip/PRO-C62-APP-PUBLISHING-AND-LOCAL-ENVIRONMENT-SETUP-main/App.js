import React from 'react';
import {Text  } from 'react-native';

export default function App() {
  return (
    
      <Text>Weather App</Text>
  );
}


